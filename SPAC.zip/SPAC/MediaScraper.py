import feedparser
import ssl

for x in rss_list:
    NewsFeed = feedparser.parse(x)
    last_entry = NewsFeed.entries[0]
    last_title = last_entry.title
    latest_title_array.append(last_title)
    # print(msg_maker(last_entry))
    index += 1
# check title for keyword
def finder(title, keyword, problem):
    t = title.lower()
    k = keyword.lower()
    instances = t.count(k)
    i = 0
    if problem:
        while i < instances:
            index = t.find(k)
            # check if following character is alnum
            if t[index + len(k)].isalnum() == False:
                return True
            # remove first instance
            t = t[index : len(t)]
            i += 1
    elif instances > 0:
        return True
    return False


# iterate through array of keywords check for each
def checker(t, k, problem):
    # special checker for problem keywords
    for x in k:
        # finds if keyword is in title
        if finder(t, x, problem):
            return True
    return False


# checks both lists of keywords
def supercheck(t, k, p):
    return checker(t, k, False) or checker(t, p, True)


# makes message
def msg_maker(entry):
    return entry.link


# get newest entry
def get_entry(url):
    NewsFeed = feedparser.parse(url)
    return NewsFeed.entries[0]


# check specific feed
def update(url, last_title):
    n = get_entry(url)
    if n.title != last_title and supercheck(n.title, keywords, problemkeywords):
        return n.title, msg_maker(n), True
        print(msg_maker(n))
    return n.title, msg_maker(n), False
