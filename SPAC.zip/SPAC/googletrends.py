from pytrends.request import TrendReq
import pandas as pd
import time

startTime = time.time()
pytrend = TrendReq(hl="en-GB", tz=360)

colnames = ["keywords"]
df = pd.read_csv("keyword_list.csv", names=colnames)
df2 = df["keywords"].values.tolist()
df2.remove("Keywords")

dataset = []

for x in range(0, len(df2)):
    keywords = [df2[x]]
    pytrend.build_payload(
        kw_list=keywords, cat=0, timeframe="2020-04-01 2020-05-01", geo="GB"
    )
    data = pytrend.interest_over_time()
    if not data.empty:
        data = data.drop(labels=["isPartial"], axis="columns")
        dataset.append(data)

print(dataset)
#result = pd.concat(dataset, axis=1)
#result.to_csv("search_trends.csv")

executionTime = time.time() - startTime
print("Execution time in sec.: " + str(executionTime))
