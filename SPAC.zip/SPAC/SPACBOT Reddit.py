# Import libraries
import requests
from urllib.request import urlopen
from datetime import date
import datetime
import pytz
import lxml
from bs4 import BeautifulSoup
import csv

cookies = dict(BCPermissionLevel="PERSONAL")

headers = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:55.0) Gecko/20100101 Firefox/55.0",
}


def getURL():
    # Construct SEC URL
    url = "https://www.reddit.com/user/SPACsBot/"

    # Connect to url and convert to html
    html = requests.get(url, headers=headers, cookies=cookies)

    # Parse and format
    soup = BeautifulSoup(html.text, "lxml")
    # Bypass cookies message
    links = soup.find_all("a")

    for i in links:
        if "spacs_under_11" in str(i.get("href")) and "reddit.com" in str(
            i.get("href")
        ):
            return i.get("href")


def getTable():
    # Construct SEC URL
    url = getURL()
    print(url)

    # Connect to url and convert to html
    html = requests.get(url, headers=headers, cookies=cookies)

    # Parse and format
    soup = BeautifulSoup(html.text, "lxml")
    with open("spactrack.csv", "w", newline="") as file:
        writer = csv.writer(file)
        for tr in soup.find_all("tr")[2:]:
            tds = tr.find_all("td")
            writer.writerow([tds[0].text, tds[1].text, tds[2].text, tds[3].text])


getTable()
