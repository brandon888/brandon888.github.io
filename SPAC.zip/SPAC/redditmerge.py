import praw

reddit = praw.Reddit(
    client_id="pgXw268OBsjmAQ",
    client_secret="XRZIHO0U23CplRr9ASjFkS9__vLp3w",
    password="1limabeaN",
    user_agent="Reddit WebScraping",
    username="thecooldudie3",
)
latest_title = ""
subreddit = "SPACs"

latest_post = reddit.subreddit(subreddit).new(limit=1)
for post in latest_post:
    latest_title = post.title


def getNew():
    newest = reddit.subreddit(subreddit).new(limit=1)
    for post in newest:
        return post.title, post.flair, post.url


def RedditDA():
    global latest_title
    title, flair, url = getNew()
    if latest_title != title:
        if flair == "Definitive Agreement" or flair == "DD":
            latest_title = title
            return url, True
    return url, False