import discord
import os
from SEC425 import msg425
import redditmerge as rm
import ssl

# 425
cookies = dict(BCPermissionLevel="PERSONAL")

# Media
rss_list = ["https://www.reddit.com/r/minecraft/new/.rss"]
keywords = ["merge", "CCIV", "Lucid", "nether"]
problemkeywords = ["EV"]
if hasattr(ssl, "_create_unverified_context"):
    ssl._create_default_https_context = ssl._create_unverified_context


client = discord.Client()


async def on_full_ready():
    notifichannel = client.get_channel(810738346233823252)
    while True:
        # checking SEC
        # msg = msg425()
        # if msg != '':
        # await notifichannel.send(msg)

        # checking Reddit
        msgDA, boolean = rm.RedditDA()
        if boolean:
            await notifichannel.send(msgDA)


# Ensuring bot is running
c = False


@client.event
async def on_ready():
    checkOn = c
    if checkOn == False:
        checkOn = True
        await on_full_ready()


TOKEN = "ODEwNzIzNTk4NTU2NzI1MjQ4.YCnzMA.ntbW8owGysaRq9oqwYfd5SPtGzE"
client.run(TOKEN)