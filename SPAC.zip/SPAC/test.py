# Import libraries
import requests
from urllib.request import urlopen
from datetime import date
import datetime
import pytz
import lxml
from bs4 import BeautifulSoup
import csv
import os

cookies = dict(BCPermissionLevel="PERSONAL")

headers = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:55.0) Gecko/20100101 Firefox/55.0",
}


def getURL(int):
    # Construct SEC URL
    return (
        "https://sheet2site-staging.herokuapp.com/api/v3/load_more.php/?key=1F7gLiGZP_F4tZgQXgEhsHMqlgqdSds3vO0-4hoL6ROQ&template=Table%20Template&filter=&search=&e=1&is_filter_multi=true&length=99&page="
        + str(int)
    )


def getListRows():
    index = 0
    trs = []
    while index <= 5:
        url = getURL(index)
        html = requests.get(url, headers=headers, cookies=cookies)
        soup = BeautifulSoup(html.text, "lxml")
        index += 1
        for tr in soup.find_all("tr")[2:]:
            trs.append(tr)
            print(type(tr))
    return trs


getListRows()

# nig nog
